#ifndef FILE_PARSER_H
#define FILE_PARSER_H

#include <QObject>
#include <QString>

class Parser : public QObject {
	Q_OBJECT

public:
	explicit Parser(QObject* parent = nullptr);
	bool parse(const QString& filePath);

private:
	bool line_process(QString& line, int line_number);
	bool is_nameInt(const QString& name);
	bool is_nameString(const QString& name);
	bool is_nameFloat(const QString& name);

signals:
	void errorOccurred(QString error);
	void parserResult(bool result);
}
#endif
