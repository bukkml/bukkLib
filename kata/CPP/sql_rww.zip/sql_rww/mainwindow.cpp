#include "mainwindow.h"

#include "ui_mainwindow.h"
#include "parser.h"
#include <QFileDialog> // подключаем возможность открыть файл с компа

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(parser, &Parser::errorOccurred,
            this, &MainWindow::on_Error);
}

void MainWindow::on_openFileButton_clicked()
{
    QString filePath;    // записываем путь открываемого файла
    filePath = QFileDialog::getOpenFileName(this, "Выбираем супер-пупер файл", "W:/Study/Job/QT/1/TEST", "Excel Tabel (*.xlsx);; Text File (*.txt);");


    ui->fileNameLabel->setText(filePath);

	Parser parser();
	parserResult_ = parser.parse(filePath);
}

void MainWindow::on_Error(QString& error) {
	ui->tableErrors->setText(error);
}

MainWindow::~MainWindow() {
	delete ui;
}
