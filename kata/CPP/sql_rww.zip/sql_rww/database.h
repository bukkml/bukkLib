#ifndef DATABASE_H
#define DATABASE_H
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>

class Database
{
public:
    Database();
    bool open();
private:
    QSqlDatabase db;
    QSqlQuery *query;
    QSqlTableModel *model;

};

#endif // DATABASE_H






