#include "file_parser.h"

#include <QString>
#include <QFile>

Parser::Parser(QObject* parent)	: QObject(parent) {}

bool Parser::is_nameInt(const QString& name) {
	bool valid = false;
	name.toInt(&valid);
	return valid;
}

bool Parser::is_nameString(const QString& name) {
	bool valid = false;
	name.toDouble(&valid);
	return valid;
}

bool Parser::is_nameFloat(const QString& name) {
	for (QChar c : name) {
		if (!c.isLetter())
			return false;
	}
	return name.isEmpty();
}

bool Parser::line_process(QString& line, int line_number) {
	QStringList row = line.split(";");

	if (row.size() != 3) {
		emit errorOccurred(
				QString("Line %1 not 3 elements")
					.arg(line_number)
				);
		return false;
	}

	bool valid = true;

	if (!is_nameInt(row[0])) {
		emit errorOccurred(
				QString("Line %1 element '%2' must be integer")
				.arg(line_number)
				.arg(row[0])
				);
		valid = false;
	}

	if (!is_nameString(row[1])) {
		emit errorOccurred(
				QString("Line %1 element '%2' must be string")
				.arg(line_number)
				.arg(row[1])
				);
		valid = false;
	}

	if (!is_nameFloat(row[2])) {
		emit errorOccurred(
				QString("Line %1 element '%2' must be float")
				.arg(line_number)
				.arg(row[2])
				);
		valid = false;
	}

	return valid;
}

bool Parser::parse(const QString& filePath) {
	if (filePath.isEmpty()) {
		emit errorOccurred("Файл не найден");
		return false;
	}

	QFile file(filePath);
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
		emit errorOccurred("Не получилось открыть файл");
		return false;
	}

	bool result = true;
	int line_number = 1;

	while(!file.atEnd()) {
		QString line = file.readLine();
		if(!line_process(line, line_number++))
			result = false;
	}
	
	return result;
}
