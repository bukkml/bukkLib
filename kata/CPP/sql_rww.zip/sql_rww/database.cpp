#include "database.h"

#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QDir> // Ддля поиска пути файла в компе
#include <QSqlTableModel>


Database::Database(){}

bool Database::open()
{

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("W:/Study/Job/QT/1/FIRSTPROJECT/DATABASE/database.db"); // Помещаем дб в папку

    if(!db.open()) {
        qDebug() << "Error opening database";
        qDebug() << db.lastError().text();
        return false;
    }

    qDebug() << QDir::currentPath(); //Выводит путь до файла

    qDebug() << "The database is open.";

   // QSqlQuery query;
    query = new QSqlQuery(db);

    query->exec("CREATE TABLE Gradebook(TelephoneNumber INT,FirstLastName TEXT,AverageScore DOUBLE);");

   // model = new QSqlTableModel(this, db); ЖАЛУЕТСЯ РАЗОБРАТЬСЯ
  //  model->setTable("Gradebook");
   // model->select();

return true;
}


//Database::Database() {}
